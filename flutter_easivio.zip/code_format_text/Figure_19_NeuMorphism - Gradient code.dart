/// Retourne un [Gradient] d'une liste derivé de [BaseColor]  en fonction du [NeumorphicType]
/// prend [lightSource] en compte pour l'orientation du gradient
Gradient? _getGradient(
    Color baseColor, int intensity, NeumorphicType type, Offset lightSource) {
  List<Color>? gradientColors;
  switch (type) {
    case NeumorphicType.concave:
      gradientColors = getColors(baseColor, intensity);
      break;
    case NeumorphicType.convex:
      gradientColors = getColors(baseColor, intensity).reversed.toList();
      break;
    case NeumorphicType.emboss:
    case NeumorphicType.flat:
    default:
      return null;
  }

  return LinearGradient(
      begin: Alignment(lightSource.dx, lightSource.dy),
      end: -Alignment(lightSource.dx, lightSource.dy),
      colors: gradientColors);
}
