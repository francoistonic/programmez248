import 'package:cloud_firestore/cloud_firestore.dart';

Future<UserModel> findUserBy(String uuid) async {
  final DocumentSnapshot ds = await FirebaseFirestore.instance
      .collection(collectionDBName)
      .doc(uuid)
      .get();
  return ds.exists
      ? UserModel.fromJson(ds.data()!)
      : throw UserNotFoundException();
}
