import 'package:flutter/material.dart';
import 'package:programmez/services/catalog_service.dart';

class HomePageViewModel with ChangeNotifier {
  HomePageViewModel() {
    _catalogService = CatalogService();
  }

  late final CatalogService _catalogService;
  double productPrice = 0.0;

  Future<void> searchProductPrice(String productId) async {
    productPrice = await _catalogService.searchProductPrice(productId);
    notifyListeners();
  }
}
