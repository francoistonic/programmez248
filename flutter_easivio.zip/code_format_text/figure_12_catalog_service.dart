import 'package:programmez/core/product.dart';
import 'package:programmez/repositories/catalog_repository.dart';

class CatalogService {
  CatalogService() {
    _catalogRepository = CatalogRepository();
  }

  late final CatalogRepository _catalogRepository;

  Future<double> searchProductPrice(String productId) async {
    final Product product = await _catalogRepository.findProduct(productId);
    return computeVAT(product.price);
  }

  double computeVAT(double price) {
    return price * 1.2;
  }
}
