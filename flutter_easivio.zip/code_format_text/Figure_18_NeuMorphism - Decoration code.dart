    decoration: BoxDecoration(
        borderRadius: borderRadius,
        border: boxBorder,
        color: color,
        gradient: _getGradient(color, intensity, neumorphicType, lightSource),