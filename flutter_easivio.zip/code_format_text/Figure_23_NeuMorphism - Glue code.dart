return neumorphicType != NeumorphicType.emboss
        ? Container(
            height: height,
            width: width,
            decoration: BoxDecoration(
              color: color,
              boxShadow: shadowList,
              gradient:
                  _getGradient(color, intensity, neumorphicType, lightSource),
            ),
          )
        :  InnerShadow(
                key: key,
                shadows: shadowList.reversed.toList(),
                child: Container(
                  height: height,
                  width: width,
                  decoration: BoxDecoration(
                    color: color,
                  ),
                ));