void listenOnUserChange(String uuid) async {
  FirebaseFirestore.instance
      .collection(collectionDBName)
      .doc(uuid)
      .listen((DocumentSnapshot ds) {
    // DO SOMETHING
  });
}
