/// A Neumorphic design container.
class NeuTestContainer extends StatelessWidget {
  const NeuTestContainer({
    Key? key,
    this.height = 150,
    this.width = 150,
    this.color = Colors.blue,
    this.neumorphicType = NeumorphicType.flat,
    this.lightSource = const Offset(-1, -1),
    this.intensity = 70,
    this.spread = 6,
    this.blur = 4,
  }) : super(key: key);

  final double height;
  final double width;
  final Offset lightSource;
  final NeumorphicType neumorphicType;
  final double blur;
  final double spread;
  final int intensity;
  final Color color;

  @override
  Widget build(BuildContext context) {
    // Intensité lumineuse
    final Offset offset =
        Offset(-lightSource.dx * spread, -lightSource.dy * spread);

    /// les ombres internes au container ?
    final List<BoxShadow> shadowList = <BoxShadow>[
      BoxShadow(
          color: getAdjustedColor(color, intensity),
          offset: -offset, // au lieu de -offset
          blurRadius: blur),
      BoxShadow(
          color: getAdjustedColor(color, 0 - intensity),
          offset: offset, // au lieu de offset
          blurRadius: blur),
    ];

    // Notre container
    return neumorphicType != NeumorphicType.emboss
        ? Container(
            height: height,
            width: width,
            decoration: BoxDecoration(
              color: color,
              boxShadow: shadowList,
              border: Border.all(color: Colors.blue[800]!, width: 2),
              gradient:
                  _getGradient(color, intensity, neumorphicType, lightSource),
            ),
          )
        : Container(
            decoration: BoxDecoration(
              border: Border.all(color: Colors.blue[800]!, width: 2),
              color: color,
            ),
            child: InnerShadow(
                key: key,
                shadows: shadowList.reversed.toList(),
                child: Container(
                  height: height,
                  width: width,
                  decoration: BoxDecoration(
                    border: Border.all(color: Colors.blue[800]!, width: 2),
                    color: color,
                  ),
                )),
          );
  }
}
