/// les ombres internes au container ?
final List<BoxShadow> shadowList = <BoxShadow>[
  BoxShadow(
      color: getAdjustedColor(color, intensity),
      offset: -offset, // au lieu de -offset
      blurRadius: blur),
  BoxShadow(
      color: getAdjustedColor(color, 0 - intensity),
      offset: offset, // au lieu de offset
      blurRadius: blur),
];
