import 'package:flutter/material.dart';
import 'package:programmez/views/home_page_view_model.dart';
import 'package:provider/provider.dart';

class MyHomePage extends StatelessWidget {
  MyHomePage({Key? key, required this.title}) : super(key: key);

  final String title;

  @override
  Widget build(BuildContext context) {
    final TextEditingController myController = TextEditingController();
    return ChangeNotifierProvider<HomePageViewModel>(
        create: (_) => HomePageViewModel(),
        builder: (BuildContext context, Widget? child) {
          return Scaffold(
            appBar: AppBar(title: Text(title)),
            body: Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[
                  TextField(
                    controller: myController,
                    decoration: InputDecoration(
                      border: OutlineInputBorder(),
                      hintText: 'Enter a search product id',
                    ),
                  ),
                  Text(
                    context.select<HomePageViewModel, String>(
                        (HomePageViewModel viewModel) =>
                            viewModel.productPrice.toString()),
                    style: Theme.of(context).textTheme.headline4,
                  ),
                ],
              ),
            ),
            floatingActionButton: FloatingActionButton(
              onPressed: () => context
                  .read<HomePageViewModel>()
                  .searchProductPrice(myController.text),
              tooltip: 'Search product price',
              child: Icon(Icons.add),
            ),
          );
        });
  }
}
