import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:programmez/core/exception.dart';
import 'package:programmez/core/product.dart';

class CatalogRepository {
  Future<Product> findProduct(final String productId) async {
    final DocumentSnapshot ds = await FirebaseFirestore.instance
        .collection('catalog')
        .doc(productId)
        .get();
    return ds.exists
        ? Product.fromJson(ds.data()!)
        : throw ProductNotFoundException();
  }
}
