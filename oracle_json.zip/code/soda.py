import os
import cx_Oracle

def connect():
    connection = cx_Oracle.connect(os.environ.get("ORACLEDB_USER"), 
                                   os.environ.get("ORACLEDB_PASSWORD"), 
                                   os.environ.get("ORACLEDB_CONNECTION_STRING"))
    connection.autocommit = True # OK for simple operations
    print( "Oracle client version: ", cx_Oracle.clientversion()[0] )
    print( "Oracle database version: ", connection.version )
    return connection
  
def run(soda):
    collection = soda.createCollection("purchase_orders")

    index_spec = { "name": "REQUESTOR_IDX",
                   "fields": [{"path": "requestor",
                               "datatype": "string",
                               "order": "asc"
                              }] }
    collection.createIndex(index_spec)

    doc = collection.insertOneAndGet({ "requestor": "Loïc Lefèvre", "address": { "city": "Tours" } })
    print( "Document key/Id is: ", doc.key )

    doc = collection.find().key(doc.key).getOne()                 # a SODA document
    print( "JSON document: ", doc.getContent() )                  # a JSON document
    print( "JSON document as string: ", doc.getContentAsString()) # a string
  
if __name__ == '__main__':
    run(connect().getSodaDatabase())
