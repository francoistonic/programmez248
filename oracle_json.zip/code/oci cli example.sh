$ oci db autonomous-database generate-wallet \
--autonomous-database-id <ocid1.autonomousdatabase....> \
--file wallet.zip --password <votre mot de passe>
$ unzip wallet.zip
$ pwd
$ export TNS_ADMIN=/home/loic_lefev
$ sed -i 's/?\/network\/admin/$TNS_ADMIN/' sqlnet.ora
