-- Création de la table contenant les taxes par pays
create table COUNTRY_TAXES (
    COUNTRY_NAME varchar2(100) not null primary key,
    TAX number(6,3) default 0.05 not null
);

-- Insertion de quelques taxes
insert into COUNTRY_TAXES (COUNTRY_NAME, TAX) values ('Luxembourg', 0.17);
insert into COUNTRY_TAXES (COUNTRY_NAME, TAX) values ('Italy',      0.22);
insert into COUNTRY_TAXES (COUNTRY_NAME, TAX) values ('France',     0.2 );
insert into COUNTRY_TAXES (COUNTRY_NAME, TAX) values ('Spain',      0.21);
commit;

-- Création de la collection SODA
soda create purchase_orders;

-- Chargement d'un document JSON, texte du document sur une seule ligne
soda insert purchase_orders { "requestor": "Loïc Lefèvre", "address": { "city": "Tours", "country": "France" }, "items": [{ "description": "Le seigneur des anneaux - 3 films", "quantity": 1, "unitPrice": 16.50 }, { "description": "The expanse - Livre 1", "quantity": 1, "unitPrice": 9.02 }]};

-- Récupération via un filtre
soda get purchase_orders -f { "address.country" : "France" }

-- Extraction en SQL du document JSON au format texte indenté (pretty)
select json_serialize(json_document pretty) from purchase_orders;

-- Création d'une vue effectuant une jointure sur le champ "country"
-- Les colonnes de la vue s'apparentent à une collection SODA : ID, CREATED_ON, JSON_DOCUMENT
create or replace view invoice as
SELECT p.id,
       p.created_on,
       -- objet JSON créé à partir de données relationnelles et de champs JSON
       json_object( 
           'purchaseOrderId'   value p.id,
           'totalPrice'        value SUM(jt.quantity * jt.unitPrice),
           'totalPriceWithVAT' value SUM(jt.quantity * jt.unitPrice * (1 + ct.tax)),
           'country'           value jt.country
       returning JSON) as JSON_DOCUMENT -- 19c: returning BLOB format OSON) as JSON_DOCUMENT
  FROM purchase_orders p nested json_document columns(
           country path '$.address.country',
           nested items[*] columns (quantity, unitPrice)
       ) jt 
       -- jointure !
       join country_taxes ct on ct.country_name = jt.country
-- aggrégation pour un même document JSON : on somme le prix de tous les items
-- multipliés par la quantité par item
GROUP BY p.id, p.created_on, jt.country;

-- Création d'une nouvelle collection SODA en lecture seule s'appuyant (mapped on) 
-- sur la vue préalablement créée (code PL/SQL)
-- 19c: "contentColumn":
--          {"name":"JSON_DOCUMENT",
--           "sqlType":"BLOB",
--           "jsonFormat":"OSON"},
declare
   METADATA varchar2(8000); -- metadata de la collection
   COL SODA_COLLECTION_T;   -- collection créée
begin
   METADATA := '{"viewName" : "INVOICE",
                 "keyColumn":{"name":"ID",
                              "sqlType":"VARCHAR2",
                              "maxLength":255,
                              "assignmentMethod":"CLIENT"},
                 "contentColumn":{"name":"JSON_DOCUMENT"},
                 "versionColumn":{"name":null},
                 "lastModifiedColumn":{"name":null},
                 "creationTimeColumn":{"name":"CREATED_ON"},
                 "readOnly":true}';

   COL := dbms_soda.create_collection('invoice', METADATA, DBMS_SODA.CREATE_MODE_MAP);
end;
/

-- Affichage des collections existantes : purchase_orders et invoice
soda list;

-- Récupération des factures depuis la vue
select i.id, 
       i.json_document.totalPrice, 
       i.json_document.totalPriceWithVAT 
from invoice i 
where i.json_document.country.string() = 'France';
