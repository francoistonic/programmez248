-- Récupération d'un document JSON depuis la collection SODA
soda get invoice -f { "country": "France" };