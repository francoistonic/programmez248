#!/bin/sh
export TNS_ADMIN=/home/loic_lefev
export ORACLEDB_USER=jsonuser
export ORACLEDB_PASSWORD=<mon mot de passe>
export ORACLEDB_CONNECTION_STRING=jsondb_tp
export LD_LIBRARY_PATH=${LD_LIBRARY_PATH}:/home/loic_lefev/instantclient_21_1
