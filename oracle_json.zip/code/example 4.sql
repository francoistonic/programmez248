-- Nouvelle table relationnelle pour génération d'objets JSON
create table employees ( name varchar2(100), job varchar2(100), wfh varchar2(5), address varchar2(100) );

insert into employees (name, job, wfh, address) values ('Loïc', 'PM', 'true', 'Tours, France');
insert into employees (name, job, wfh) values ('Mike', 'Developer', 'false');

-- 2 documents JSON générés (1 pour chaque ligne)
select JSON_OBJECT( 'name' value name, 'job' value job ) from employees;

-- 1 document JSON généré aggrégeant les 2 lignes dans un tableau trié par "name"
-- Le champ wfh est converti en valeur JSON booléenne
-- Le champ address est omis dans le document JSON si sa valeur relationnelle est NULL
-- Ajout du champ calculé "count" correspondant au nombre de lignes / employés
select JSON_OBJECT( 'allEmployees' value JSON_ARRAYAGG( 
                             JSON_OBJECT( 'name' value name, 
                                          'job' value job, 
                                          'wfh' value wfh format JSON, 
                                          'address' value address ABSENT ON NULL 
                                        ) order by name), 
                    'count' value count(*)
                  )  
from employees;
