-- Projection des valeurs JSON en colonnes relationnelles avec valeurs imbriquées
-- Notation avec opérateur standard JSON_TABLE()
select e.*
  from emp,
       JSON_TABLE( emp.data, '$' columns (
                   name,
                   job,
                   salary,
                   nested phones[*] columns (
                       type,
                       num
                   )
                  )
                 ) e;
